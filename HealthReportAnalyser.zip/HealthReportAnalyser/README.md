# HealthReportAnalyser
It is a complete Machine Learning project. It currently works for 5 diseases but is scalable in the future. If you enter the details of the health report, it will analyze the report and predict whether the person is affected by a particular disease.
